This Strategy Room Tab is used as a sandbox for helping you with KC3 development.

Not that all changes to this directory should not be commited to the repository,
you can do the following so Git will ignore all changes you made to this directory:

```bash
$ cd </path/to/repo/home>
$ cd src/pages/strategy/tabs/playground
$ git update-index --assume-unchanged *
```

You have to do this once for all files you put in this directory
